from .main import AudioRecorder

__all__ = ["AudioRecorder"]
